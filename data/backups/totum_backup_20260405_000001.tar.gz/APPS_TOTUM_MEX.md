# 🎯 APPS TOTUM + MEX
## Sistema de Contexto Integrado

---

## 📁 Estrutura do Projeto

```
apps_totum/                      ← Repo principal
│
├── 📁 .mex/                     ← Sistema de Contexto (MEX)
│   ├── mex.md                   ← Bootstrap do projeto
│   ├── routing.yaml             ← Rotas para cada App
│   ├── architecture.md          ← Arquitetura geral
│   ├── conventions.md           ← Padrões de código
│   ├── decisions/               ← ADRs (Architecture Decision Records)
│   │   ├── 001-stack-totum.md
│   │   ├── 002-banco-dados.md
│   │   └── 003-integracao-mcp.md
│   ├── patterns/                ← Padrões reutilizáveis
│   │   ├── INDEX.md
│   │   ├── autenticacao.md
│   │   ├── erros.md
│   │   └── logging.md
│   └── state.md                 ← Estado atual do ecossistema
│
├── 📁 apps/                     ← Apps individuais (cada um com seu .mex/)
│   ├── 📁 atendente/
│   │   ├── .mex/                ← Contexto específico do app
│   │   │   ├── mex.md
│   │   │   ├── routing.yaml     ← Roteia dúvidas → contexto
│   │   │   ├── knowledge/       ← Base de conhecimento do app
│   │   │   │   ├── faq.md
│   │   │   │   ├── processos.md
│   │   │   │   └── scripts.md
│   │   │   └── state.md         ← Estado das conversas
│   │   ├── src/
│   │   └── dockerfile
│   │
│   ├── 📁 trafego/
│   │   ├── .mex/
│   │   │   ├── knowledge/
│   │   │   │   ├── metricas.md
│   │   │   │   ├── anomalias.md
│   │   │   │   └── criativos.md
│   │   │   └── state.md
│   │   └── src/
│   │
│   ├── 📁 radar/
│   │   ├── .mex/
│   │   │   ├── knowledge/
│   │   │   │   ├── clientes/
│   │   │   │   ├── referencias/
│   │   │   │   └── trends.md
│   │   │   └── state.md
│   │   └── src/
│   │
│   └── 📁 admin/                ← App de gerenciamento
│       ├── .mex/
│       └── src/
│
├── 📁 context_hub/              ← Central de Contexto (API)
│   ├── api/                     ← FastAPI
│   ├── core/                    ← ChromaDB + Curator
│   └── data/                    ← Vector store
│
├── 📁 packages/                 ← Pacotes compartilhados
│   ├── totum-context/           ← SDK para acessar contexto
│   ├── totum-mcp/               ← Integrações MCP
│   └── totum-ui/                ← Componentes UI
│
├── 📁 infrastructure/           ← Infra as Code
│   ├── docker/
│   ├── k8s/
│   └── terraform/
│
├── 📁 docs/                     ← Documentação global
│   ├── vision.md
│   ├── roadmap.md
│   └── api-reference.md
│
├── mex.config.yaml              ← Config do MEX para o monorepo
└── package.json                 ← Scripts do MEX
```

---

## 🔄 Como Funciona

### 1. Contexto em 3 Níveis

```
Nível 1: Global (apps_totum/.mex/)
├── Arquitetura do ecossistema
├── Decisões que afetam todos os apps
├── Padrões compartilhados
└── Estado geral do projeto

Nível 2: App (apps/atendente/.mex/)
├── Conhecimento específico do app
├── Base de dados do domínio
├── Scripts e processos
└── Estado das operações

Nível 3: Sessão (runtime)
├── Contexto da conversa atual
├── Dados temporários
└── Cache de consultas
```

### 2. Fluxo de Roteamento

```yaml
# apps/atendente/.mex/routing.yaml
routes:
  # Dúvidas sobre preço → knowledge/faq.md
  - pattern: "preço|custo|valor|orçamento"
    target: "knowledge/faq.md"
    priority: 1
    
  # Problemas técnicos → knowledge/processos.md
  - pattern: "erro|bug|problema|não funciona"
    target: "knowledge/processos.md"
    priority: 2
    
  # Escalar → notificar humano
  - pattern: "reclamação|urgente|diretor"
    target: "ESCALAR"
    priority: 0
    
  # Fallback → consultar Context Hub
  - pattern: ".*"
    target: "CONTEXT_HUB"
    priority: 99
```

### 3. Sincronização

```python
# Quando um app aprende algo novo:

1. Atendente processa dúvida sobre "preço X"
2. Descobre que o preço mudou
3. Atualiza: apps/atendente/.mex/knowledge/faq.md
4. Envia para Context Hub (cross-apps)
5. Radar (outro app) fica sabendo da mudança
```

---

## 🛠️ Setup Inicial

```bash
# 1. Clonar MEX no projeto
cd apps_totum
git clone https://github.com/theDakshJaitly/mex.git .mex

# 2. Configurar para monorepo
cat > mex.config.yaml << 'EOF'
project:
  name: "Apps Totum"
  type: "monorepo"
  
scaffold:
  root: ".mex/"
  apps_dir: "apps/"
  
apps:
  - name: "atendente"
    path: "apps/atendente/"
    type: "telegram-bot"
    
  - name: "trafego"
    path: "apps/trafego/"
    type: "service"
    
  - name: "radar"
    path: "apps/radar/"
    type: "service"

integrations:
  context_hub: "context_hub/api/main.py"
  auto_sync: true
EOF

# 3. Setup
bash .mex/setup.sh

# 4. Criar scaffolds para cada app
mex app init atendente
tmex app init trafego
mex app init radar
```

---

## 🔗 Integração com Context Hub

```python
# packages/totum-context/sdk.py

class TotumContext:
    """SDK oficial do Apps Totum para gerenciar contexto"""
    
    def __init__(self, app_name: str):
        self.app_name = app_name
        self.mex_path = f"apps/{app_name}/.mex/"
        self.hub_client = ContextHubClient()
    
    def load_context(self, query: str) -> str:
        """Carrega contexto relevante para a query"""
        
        # 1. Verificar routing do MEX
        route = self._check_mex_routing(query)
        
        if route and route != "CONTEXT_HUB":
            # Carregar do scaffold local
            return self._load_mex_file(route)
        
        # 2. Consultar Context Hub (busca semântica)
        hub_results = self.hub_client.query(
            query=query,
            app=self.app_name,
            n_results=3
        )
        
        # 3. Combinar resultados
        return self._combine_context(hub_results)
    
    def save_learning(self, content: str, tags: list):
        """Salva aprendizado no MEX + Hub"""
        
        # Salvar no scaffold local
        self._append_to_mex_state(content)
        
        # Sincronizar com Hub
        self.hub_client.store(
            content=content,
            app=self.app_name,
            tags=tags
        )
```

---

## 📊 Vantagens dessa Arquitetura

| Aspecto | Benefício |
|---------|-----------|
| **Modular** | Cada app tem seu contexto isolado |
| **Compartilhado** | Context Hub sincroniza entre apps |
| **Eficiente** | MEX bootstrap (~120 tokens) + routing |
| **Atualizado** | Drift detection mantém docs frescos |
| **Escalável** | Novos apps = novo .mex/ |

---

## 🤖 Agentes da Totum (Equipe MEX)

Sistema de agentes autônomos integrados ao MEX para operações 24/7.

### Arquitetura Hub-and-Spoke

```
                    TOT (Orquestrador)
                         │
        ┌────────────────┼────────────────┐
        │                │                │
    PABLO            DATA              HUG
   (Executor)     (Desenvolvedor)   (Atendimento)
        │                │                │
   ┌────┴────┐      ┌────┴────┐      ┌────┴────┐
   │         │      │         │      │         │
WALL·E    EVE     RICO     KOWALSKI  BLÔ    CHANDLER
(Limpeza) (Monitor) (Testes) (Análise) (Trends BR) (Social)
   │         │      │         │      │         │
   └─────────┴──────┴─────────┴──────┴─────────┘
                         │
                    WATSON 🕵️
               (Análise Estratégica)
                         │
                    TRANSCRITOR 🎙️
               (Processamento de Vídeo)
```

### Agente Principal: TOT
- **Função:** Orquestrador geral
- **Responsabilidade:** Coordenar todos os agentes, tomar decisões estratégicas
- **Emoji:** 🎛️

### Modos de Operação

| Agente | Modo | Emoji | Função |
|--------|------|-------|--------|
| **PABLO** | Executor | 🎯 | Executar tarefas, gerenciar projetos |
| **DATA** | Desenvolvedor | 💻 | Codificar, debugar, implementar |
| **HUG** | Atendimento | 🤗 | Receber clientes, triar demandas |

### Equipe de Conhecimento (Indexação & Organização)

**Trabalham sob demanda** — quando necessário organizar, catalogar ou analisar.

| Agente | Emoji | Função | Referência | Uso |
|--------|-------|--------|------------|-----|
| **GILES** | 🧙‍♂️ | Bibliotecário/Indexador | Buffy | Cataloga POPs, SLAs, Skills no índice central |
| **MONK** | 🧤 | Organização Obsessiva | Monk (série) | Estrutura dados, elimina duplicatas, padroniza |
| **WATSON** | 🕵️ | Análise Dedutiva | Sherlock Holmes | Conecta pontos, encontra padrões, aplica insights |

### Equipe de Ferramentas (Processamento)

**Ativados sob demanda** — quando precisar processar conteúdo específico.

| Agente | Emoji | Função | Uso |
|--------|-------|--------|-----|
| **TRANSCRITOR** | 🎙️ | Vídeos/Áudio | Recebe URL → Entrega transcrição |
| **TOOLIFY** | 🛠️ | Radar de Ferramentas | Monitora novidades de produtividade |

### Protocolo "Eu Vou Dormir" (Ativação Noturna)

**NÃO são agentes exclusivamente noturnos** — são agentes especializados que têm **ações definidas e recorrentes** no protocolo noturno, mas trabalham sempre que necessário.

| Agente | Emoji | Função no Protocolo | Uso Geral |
|--------|-------|---------------------|-----------|
| **WALL·E** | 🗑️ | Limpeza e otimização de sistemas | Otimiza sempre que detecta gargalo |
| **EVE** | 🔫 | Monitoramento de alertas e métricas | Monitora 24/7, alerta quando necessário |
| **RICO** | 💥 | Testes caóticos em staging | Testa quando há deploy ou mudança |
| **BLÔ** | 💅 | Análise de trends Brasil | Reporta trends quando detecta |
| **CHANDLER** | ☕ | Análise de métricas sociais | Analisa quando há dados novos |
| **GIT** | 🐙 | Scout de repositórios trending | Varre GitHub quando solicitado |
| **RADAR** | 📡 | Análise de trends Global | Reporta tendências globais |

### Configuração do Protocolo

```yaml
nome: "Eu Vou Dormir"
descricao: "Ativação recorrente de agentes especializados"
horario_ativacao: "22:30"
horario_relatorio: "08:00"

# IMPORTANTE: Estes agentes trabalham SOB DEMANDA também!
# O protocolo é apenas UM momento de ativação entre muitos.

fluxo_noturno:
  22:30:
    - wall_e: "Limpeza e otimização de sistemas"
    - eve: "Monitoramento de alertas e métricas"
    - rico: "Testes caóticos em staging"
    - git: "Scout de repositórios trending"
    - blo: "Análise de trends Brasil"
    - radar: "Análise de trends Global"
    - transcritor: "Processamento de vídeos pendentes"
    - monk: "Organização obsessiva de dados"
    - watson: "Análise estratégica compilada"
  
  03:00:
    - compilador: "Gera relatório matinal unificado"
  
  08:00:
    - entrega: "Israel recebe briefing completo"

uso_geral:
  descricao: "Qualquer agente pode ser chamado a qualquer momento"
  exemplos:
    - "Giles, indexe esse novo POP"
    - "Watson, analise esse vídeo agora"
    - "Rico, teste essa nova feature"
    - "Transcritor, processe esse áudio"

entrega:
  formato: "Relatório Markdown"
  conteudo:
    - Resumo executivo
    - Novidades técnicas
    - Trends identificadas
    - Análises de vídeos
    - Recomendações prioritárias
    - Próximos passos
```

Ativada às 22:30, entrega relatório às 08:00.

| Agente | Emoji | Função | Referência |
|--------|-------|--------|------------|
| **WALL·E** | 🗑️ | Otimização/Limpeza | WALL·E (Pixar) |
| **EVE** | 🔫 | Monitoramento | WALL·E (Pixar) |
| **RICO** | 💥 | Testes Caóticos | Madagascar |
| **MONK** | 🧤 | Organização Obsessiva | Monk (série) |
| **WATSON** | 🕵️ | Análise Dedutiva | Sherlock Holmes |
| **BLÔ** | 💅 | Trends Brasil | Blogueirinha |
| **CHANDLER** | ☕ | Social Media | Friends |
| **GIT** | 🐙 | GitHub Scout | Octocat |
| **RADAR** | 📡 | Trends Global | - |
| **TRANSCRITOR** | 🎙️ | Vídeos/Áudio | Whisper |

### Agentes em Desenvolvimento

| Agente | Status | Descrição |
|--------|--------|-----------|
| **Reportei** | 🔄 Planejado | Geração de relatórios Meta |
| **Fignaldo** | 🔄 Planejado | Design System → protótipos |
| **KVirtuoso** | 🔄 Planejado | Geração de posts em massa |
| **Radar de Anúncios** | 🔄 Planejado | Inteligência competitiva |
| **Ghost** | 🔄 Planejado | Testes caóticos avançados |
| **Zelador** | 🔄 Planejado | Code cleanup/refactoring |

### Integração MEX

Cada agente tem seu contexto no MEX:

```
.mex/agents/
├── tot.md              # Orquestrador
├── pablo.md            # Modo Executor
├── data.md             # Modo Desenvolvedor
├── hug.md              # Modo Atendimento
├── giles.md            # Bibliotecário/Indexador ⭐ NOVO
├── wall-e.md           # Otimização
├── eve.md              # Monitoramento
├── rico.md             # Testes
├── monk.md             # Organização
├── watson.md           # Análise
├── blo.md              # Trends BR
├── chandler.md         # Social Media
├── git.md              # GitHub
├── radar.md            # Trends Global
└── transcritor.md      # Processamento
└── transcritor.md      # Processamento

---

## 🎯 Próximos Passos

1. **Criar repo `apps_totum`** (se ainda não existir)
2. **Integrar MEX** na raiz do projeto
3. **Criar Context Hub** como serviço compartilhado
4. **Desenvolver SDK** `totum-context`
5. **Migrar Bot Atendente** para usar o sistema
6. **Implementar Protocolo "Eu Vou Dormir"** — Ativação recorrente (não exclusiva) de agentes especializados

Quer que eu comece a **implementar essa estrutura** no workspace? 🚀
